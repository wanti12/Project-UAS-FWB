<img src="./ynzwhmsy.png"
style="width:1.66653in;height:1.62986in" />

> **DesaInvolve** **(sistem** **informasi** **kegiatan** **desa)**
>
> Wanti D0223026
>
> Framework Web Based 2025

**Role** **dan** **Fitur-fiturnya**

> **1.** **Pemerintah** **(Admin)**
>
> Role yangmewakili aparatur desa, yang bertanggung jawab memverifikasi
> dan mengelola kegiatan serta memantau partisipasi warga.
>
> **Fitur** **utama:**
>
> a\. Melihat daftar kegiatan baik yang status pending, approved, atau
> rejected b. Menyetujui atau menolak kegiatan yang di ajukan oleh
> penyelenggara
>
> c\. Melihat laporan pendaftaran warga ke kegiatan d. Melihat data
> warga dan penyelenggara
>
> **2.** **Penyelenggara**
>
> Role organisasi atau kelompok yang bertanggung jawab mengusulkan dan
> menjalankan kegiatan **Fitur** **utama:**
>
> a\. Mengajukan kegiatan
>
> b\. Melihat status kegiatan yang diajukan (pending, approve, atau
> rejected) c. Melihat daftar warga yang mendaftar ke kegiatan mereka
>
> d\. **3.** **Warga**
>
> Role masyarakat umum yang bisa mendaftar kegiatan desa dan membarikan
> komentar. **Fitur** **utama:**
>
> a\. Melihat daftar kegiatan yang tersedia dengan status approved b.
> Mendaftar kegiatan yang diinginkan
>
> c\. Melihat riwayat pendaftaran kegiatan
>
> d\. Memberikan komentar terhadap kegiatan

**Tabel-tabel** **database** **beserta** **field** **dan** **tipe**
**datanya** **1.** **Tabel** **user**

||
||
||
||
||
||
||
||
||
||
||

> **2.** **Wargas**

||
||
||
||
||
||
||
||
||
||
||

> **3.** **Pemerintas**

||
||
||
||
||
||
||
||

> **4.** **Penyelenggaras**

||
||
||
||
||
||
||
||

> **5.** **Kegiatans**

||
||
||
||
||
||
||
||
||
||
||
||

> **6.** **Pendaftarans**

||
||
||
||
||
||
||
||

> **7.** **Komentars**

||
||
||
||
||
||
||
||
||

**Jenis** **relasi** **dan** **tabel** **yang** **berelasi**

||
||
||
||
||
||
||
||
||
||
